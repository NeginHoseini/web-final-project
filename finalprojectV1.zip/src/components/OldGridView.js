import {Link} from "react-router-dom";
import {useEffect, useState} from "react";
import axios from "axios";
import MovieGrid from "./GridCard";
import MovieList from "./ListCard";
import Header from "./Header";
import {BsFillGrid3X3GapFill, BsList} from "react-icons/bs";



export default function OldGridView() {


    const [list,setList] = useState(true);

    function gridView() {
        setList(false);
    }

    function listView() {
        setList(true);
    }


    // const state = {list};


    const [movies, setMovies] = useState([]);

    useEffect(() => {
        getMovies();
    }, []);

    function getMovies() {
        axios.get('http://localhost:8888/api/movies/').then(function(response) {
            console.log(response.data);
            setMovies(response.data);
        });
    }


    return (
        <>
        {/*<div>*/}
        {/*    /!*<h1>List Movies</h1>*!/*/}
        {/*    /!*<table cellSpacing={15}>*!/*/}
        {/*    /!*    <thead>*!/*/}
        {/*    /!*    <tr>*!/*/}
        {/*    /!*        <th>#</th>*!/*/}
        {/*    /!*        <th>Name</th>*!/*/}
        {/*    /!*        <th>Year</th>*!/*/}
        {/*    /!*        <th>Description</th>*!/*/}
        {/*    /!*        <th>Poster</th>*!/*/}
        {/*    /!*    </tr>*!/*/}
        {/*    /!*    </thead>*!/*/}
        {/*    /!*    <tbody>*!/*/}
        {/*    /!*    {movies.map((movie, key) =>*!/*/}
        {/*    /!*        <tr key={key}>*!/*/}
        {/*    /!*            <td>{movie.id}</td>*!/*/}
        {/*    /!*            <td>{movie.name}</td>*!/*/}
        {/*    /!*            <td>{movie.year}</td>*!/*/}
        {/*    /!*            <td>{movie.description}</td>*!/*/}
        {/*    /!*            <td>{movie.poster}</td>*!/*/}
        {/*    /!*            <td>*!/*/}
        {/*    /!*                /!*<Link to={`user/${user.id}/edit`} style={{marginRight: "10px"}}>Edit</Link>*!/*!/*/}
        {/*    /!*                /!*<button onClick={() => deleteUser(user.id)}>Delete</button>*!/*!/*/}
        {/*    /!*            </td>*!/*/}
        {/*    /!*        </tr>*!/*/}
        {/*    /!*    )}*!/*/}

        {/*    /!*    </tbody>*!/*/}
        {/*    /!*</table>*!/*/}

        {/*    <section id={"gridMovies"}*/}
        {/*    style={{*/}
        {/*        margin:"5% auto",*/}
        {/*        width: "95%" ,*/}
        {/*        background:"#114431",*/}
        {/*        borderRadius: "15px",*/}
        {/*        padding: "2%",*/}
        {/*    }}*/}
        {/*    >*/}
        {/*        <h1*/}
        {/*            style={{*/}
        {/*               color:"white",*/}
        {/*               fontFamily:"Andalus",*/}
        {/*            }}*/}
        {/*        >Movies</h1>*/}
        {/*        /!*<div  className={"moviesCnt py-3  d-flex justify-content-around "}>*!/*/}
        {/*        /!*<div  className={"w-full grid grid-cols-4 gap-4  justify-between justify-items-stretch space-y-3 space-x-6 rounded-xl  xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 p-11"}>*!/*/}

        {/* /!*           <div*!/*/}
        {/* /!*               className="*!/*/}
        {/* /!*py-3 d-flex justify-content-around col-md-3"*!/*/}
        {/* /!*           >*!/*/}


        {/*            {movies.map((movie, key) => (*/}
        {/*                <MovieGrid id={movie.id}*/}
        {/*                      name={movie.name}*/}
        {/*                      year={movie.year}*/}
        {/*                      description={movie.description}*/}
        {/*                      poster={movie.poster}*/}
        {/*                      key={key} />*/}
        {/*                 ))}*/}
        {/*            /!*</div>*!/*/}
        {/*        /!*</div>*!/*/}
        {/*    </section>*/}
        {/*    <br/>*/}
        {/*</div>*/}



        <div>
            {true ? (
                    <div>
                    <section id={"gridMovies"}

                             style={{
                                 margin:"5% auto",
                                 width: "95%" ,
                                 background:"#114431",
                                 borderRadius: "15px",
                                 padding: "2%",
                             }}
                    >
                        <div className={"row"}>

                            <h1 className={"col-md-7 text-end"}
                                style={{
                                    color:"white",
                                    fontFamily:"Andalus",
                                    paddingRight:"3%"
                                }}
                            >Movies</h1>

                            <div className={"col-md-4 text-end pt-1"}>

                        <button className={"border-0 "} style={{
                            // width:"50%",
                            // height:"30%",
                            background:"#114431",
                            marginRight:"5%",
                        }}
                            // onClick={() => listView()}
                        >
                            <BsList style={{color:"white"}} size={30}></BsList>
                        </button>

                        <button className={"border-0 "} style={{
                            // width:"50%",
                            // height:"30%",
                            background:"#114431"
                        }}
                            // onClick={() => gridView()}
                        >
                            <BsFillGrid3X3GapFill className={"mt-1"} style={{color:"white"}} size={22}></BsFillGrid3X3GapFill>
                        </button>
                            </div>

                             </div>
                        {/*<div  className={"moviesCnt py-3  d-flex justify-content-around "}>*/}
                        {/*<div  className={"w-full grid grid-cols-4 gap-4  justify-between justify-items-stretch space-y-3 space-x-6 rounded-xl  xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 p-11"}>*/}

                        {/*           <div*/}
                        {/*               className="*/}
                        {/*py-3 d-flex justify-content-around col-md-3"*/}
                        {/*           >*/}


                        {movies.map((movie, key) => (
                            <MovieList id={movie.id}
                                       name={movie.name}
                                       year={movie.year}
                                       description={movie.description}
                                       poster={movie.poster}
                                       key={key} />
                        ))}
                        {/*</div>*/}
                        {/*</div>*/}
                    </section>
                <br/>
                    </div>

            ) : (

<div>
                <section id={"gridMovies"}
                         style={{
                             margin:"5% auto",
                             width: "95%" ,
                             background:"#114431",
                             borderRadius: "15px",
                             padding: "2%",
                         }}
                >
                    <h1
                        style={{
                            color:"white",
                            fontFamily:"Andalus",
                        }}
                    >Movies</h1>
                    {/*<div  className={"moviesCnt py-3  d-flex justify-content-around "}>*/}
                    <div  className={"w-full grid grid-cols-4 gap-4  justify-between justify-items-stretch space-y-3 space-x-6 rounded-xl  xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 p-11"}>

                    {/*           <div*/}
                    {/*               className="*/}
                    {/*py-3 d-flex justify-content-around col-md-3"*/}
                    {/*           >*/}


                    {movies.map((movie, key) => (
                        <MovieGrid id={movie.id}
                                   name={movie.name}
                                   year={movie.year}
                                   description={movie.description}
                                   poster={movie.poster}
                                   key={key} />
                    ))}
                    </div>
                    {/*</div>*/}
                </section>
                <br/>

</div>
            )}


        </div>

        </>
    )
}
import './AddMovieStyle.css';
import axios from "axios";
import {useEffect, useState} from "react";
import {useNavigate} from "react-router-dom";
import GridView from "./OldGridView";
import {Link} from "react-router-dom";
import ShowMovies from "./ShowMovies";

export default function AddMovie({list}){

     // const navigate = useNavigate();


    const[input,setInput]=useState(
        {
            name:'',
            year:'',
            description:'',
            poster:'',
        });


    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setInput(values => ({...values, [name]: value}));
    }

    const handleSubmit = (event) => {
        event.preventDefault();
        if(isNaN(input.year)){
            alert("Movie not added. Enter the information correctly!");
            // setInfo("Movie not added. Enter the information correctly!")
            // console.log(info);
        }else{
            axios.post('http://localhost:8888/api/movie/create', input).then(function(response){
                console.log(response.data);

                // navigate('/');
                setInput({
                    name:'',
                    year:'',
                    description:'',
                    poster:'',
                });

                // setInfo("Movie added successfully!")
                // console.log(info);
            });



        }
    }

    return(
        <div>
                <form onSubmit={handleSubmit} className="addContainer container">
                    <div className={"inForm"}>

                    <h1 style={{fontFamily : "Bahnschrift Condensed"}}>Add Movie</h1>

                    <input type="text" placeholder="Movie Name" name="name" value={input.name} required onChange={handleChange}/>

                    <input type="text" placeholder="Movie Year" name="year" value={input.year} required onChange={handleChange}/>

                    <textarea placeholder="Description" name="description" value={input.description} required onChange={handleChange}/>

                    <input className={"poster"} type="text" placeholder="Poster URL" name="poster" value={input.poster} required onChange={handleChange}/><br/>

                    <button type="submit" className="addBtn">Add</button><br/>


                    </div>
                </form>

            <ShowMovies />

        </div>
    )
}

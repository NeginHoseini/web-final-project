import {Link} from "react-router-dom";
import {FaEdit} from "react-icons/fa";
import {MdDelete} from "react-icons/md";
import axios from "axios";
import {useEffect, useState} from "react";

export default function GridCard({id,name,year,description,poster}){

    const [movies, setMovies] = useState([]);

    useEffect(() => {
        getMovies();
    }, []);

    function getMovies() {
        axios.get('http://localhost:8888/api/movies/').then(function(response) {
            console.log(response.data);
            setMovies(response.data);
        });
    }


    const deleteMovie = () => {
        // alert("click Delete!");

        axios.delete(`http://localhost:8888/api/movies/${id}/delete`).then(function(response){
            console.log(response.data);
            getMovies();
        });
    }


    return(


<div className={"col-3 p-4"}>
            <div className="card shadow mt-5 m-2 " style={{ fontFamily:"Bahnschrift Condensed"}} >

                <img className="card-img-top" src={poster} alt="movie poster" style={{height:"45vh"}}/>

                <div className="card-body" style={{height: "18vh"}} >
                    <h5 className="card-title" style={{fontFamily:"Algerian" , }}>{name}</h5>
                    <p className="card-text">({year})</p>

                    <Link to={`movie/${id}/detail`} >
                        <button className={"btn btn-success"} style={{marginRight:"15%"}}>Read More...</button>
                    </Link>

                    <Link to={`movie/${id}/edit`} >
                    <button className={"border-0 "} style={{
                        height:"30%",
                        background:"white"
                    }}
                    >
                        <FaEdit size={30}></FaEdit>
                    </button>
                    </Link>

                    <button onClick={() => deleteMovie()} className={"border-0 mx-2"} style={{
                        height:"30%",
                        background:"white"
                    }}
                    >
                        <MdDelete size={30}></MdDelete>
                    </button>

                </div>
            </div>
</div>


    )

}
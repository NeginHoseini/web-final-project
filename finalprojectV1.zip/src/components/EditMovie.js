import './EditStyle.css'
import {useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import axios from "axios";

export default function EditMovie(){
    const navigate = useNavigate();

    const [movie, setMovie] = useState([]);

    const {id} = useParams();

    useEffect(() => {
        getUser();
    }, []);

    function getUser() {
        axios.get(`http://localhost:8888/api/movie/${id}`).then(function(response) {
            console.log(response.data);
            setMovie(response.data);
        });
    }

    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setMovie(values => ({...values, [name]: value}));
    }
    const handleSubmit = (event) => {
        event.preventDefault();

        axios.put(`http://localhost:8888/api/movie/${id}/edit`, movie).then(function (response) {
            console.log(response.data);
            navigate('/');
        });

    }

        return(
        <div className={"movieEditContainer"}>
            <div className={"innerEditCnt shadow"}>

                <h1  style={{fontFamily : "Bahnschrift Condensed", color:"white"}}>Edit Movie</h1>
                <form onSubmit={handleSubmit} className="container m-4 text-start">
                    <div>
                        <div className={"row"}>
                            <div className={"col-6"}>
                        <label className={"formLbl"}>Movie Name  </label>
                        <input type="text"  className={"editInputs border-0"} name="name" value={movie.name}  required onChange={handleChange}/>
                            </div>
                            <div className={"col-6"}>
                        <label className={"formLbl"}>Movie Year  </label>
                        <input type="text" className={"editInputs border-0"} name="year" value={movie.year} required onChange={handleChange}/>
                            </div>
                        </div>

                        <label className={"formLbl"}>Poster  </label>
                        <input className={"ePoster border-0"} type="text" name="poster"  value={movie.poster} required onChange={handleChange}/><br/>

                        <label className={"formLbl"}>Description  </label>
                        <textarea className={"eDesc border-0"} name="description"  value={movie.description} required onChange={handleChange}/>

                        <button type="submit" className="editBtn col-5">Save Changes</button><br/>
                        <button className="cancelBtn" onClick={()=> navigate('/')}>Cancel</button>



                    </div>
                </form>

            </div>
        </div>
    )
}
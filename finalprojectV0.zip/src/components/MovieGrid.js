import './MovieGridStyle.css';

export default function MovieGrid({id,name,year,description,poster}){

    return(
        <div>
            {/*<div className={"container"}>*/}
            {/*    <div className={"row justify-content-center"}>*/}

            {/*        <div className={"col-md-4"}>*/}
            {/*            <div className="card shadow" style={{width: "20rem"}} >*/}

            {/*                <img className="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxeh8lfXzQZuu9JUfXFb05g34EsbeJZeveBQ&usqp=CAU"*/}
            {/*                     alt="Card image cap" />*/}

            {/*                    <div className="card-body">*/}
            {/*                        <h5 className="card-title">Leon</h5>*/}
            {/*                        <p className="card-text text-start">(1994)</p>*/}
            {/*                        <a href="#" className="btn btn-primary">Read More...</a>*/}
            {/*                    </div>*/}
            {/*            </div>*/}
            {/*        </div>*/}


            {/*        <div className={"col-md-4"}></div>*/}
            {/*        <div className={"col-md-4"}></div>*/}
            {/*    </div>*/}

            {/*</div>*/}


            <div className="card shadow " style={{width: "20rem"}} >

                {/*<img className="card-img-top" src={poster} alt="movie poster" />*/}
                <img className="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxeh8lfXzQZuu9JUfXFb05g34EsbeJZeveBQ&usqp=CAU" alt="movie poster" />

                <div className="card-body" style={{height: "18vh"}} >
                    <h5 className="card-title" style={{fontFamily:"Century Schoolbook" , color: "#18543c"}}>{name}</h5>
                    <p className="card-text">({year})</p>

                    {/*<a href="#" className="btn btn-primary text-end">Read More...</a>*/}
                    {/*<a >Read More...</a>*/}
                </div>
            </div>


        </div>

    )

}
import {FaEdit} from "react-icons/fa";
import {MdDelete} from "react-icons/md";
import {Link} from "react-router-dom";
import axios from "axios";
import {useEffect, useState} from "react";


export default function MovieList({id,name,year,description,poster}) {


    const [movies, setMovies] = useState([]);

    useEffect(() => {
        getMovies();
    }, []);

    function getMovies() {
        axios.get('http://localhost:8888/api/movies/').then(function(response) {
            console.log(response.data);
            setMovies(response.data);
        });
    }


    const deleteMovie = () => {
        // alert("click Delete!");

        axios.delete(`http://localhost:8888/api/movies/${id}/delete`).then(function(response){
            console.log(response.data);
            getMovies();
        });
    }

    return (
        <div>
            {/*<div className="card shadow " style={{width: "20rem"}} >*/}

            {/*    /!*<img className="card-img-top" src={poster} alt="movie poster" />*!/*/}
            {/*    <img className="card-img-left" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTxeh8lfXzQZuu9JUfXFb05g34EsbeJZeveBQ&usqp=CAU" alt="movie poster" />*/}

            {/*    <div className="card-body" style={{height: "18vh"}} >*/}
            {/*        <h5 className="card-title" style={{fontFamily:"Century Schoolbook" , color: "#18543c"}}>{name}</h5>*/}
            {/*        <p className="card-text">({year})</p>*/}

            {/*        /!*<a href="#" className="btn btn-primary text-end">Read More...</a>*!/*/}
            {/*        /!*<a >Read More...</a>*!/*/}
            {/*    </div>*/}
            {/*</div>*/}


            <div className={"card"}
            style={{
                width:"80%",
                height: "20vh",
                margin:"2% auto",
                background:"#939896",
                fontFamily:"Bahnschrift Condensed",

            }}
            >
                <div className={"row"}>
                    <div className="col-md-3" style={{
                        // border:"red 2px solid"
                    }}>
                        <img
                            style={{height:"18vh"}}
                            className="img-fluid mt-2" src={poster} alt="movie poster" />

                    </div>
                    <div className="col-md-3" style={{
                        fontFamily:"Algerian",
                    }}>
                                    <h3 className={"card-title mt-5 text-start"}> {name} </h3>
                    </div>

                    <div className="col-md-2">
                        <h3 className={"mt-5 text-start"}>({year})</h3>
                    </div>

                    <div className="col-md-2">
                        <Link to={`movie/${id}/detail`} >
                        <button className={"btn btn-success mt-5"}>Read More...</button>
                        </Link>
                    </div>

                    <div className="col-md-2">
                        <button className={"border-0 mt-5 mx-3"} style={{
                            height:"30%",
                            background:"#939896"
                        }}
                        >
                            <FaEdit size={30}></FaEdit>
                        </button>

                        <button onClick={() => deleteMovie()} className={"border-0 mt-5"} style={{
                            height:"30%",
                            background:"#939896"
                        }}
                        >
                        <MdDelete size={30}></MdDelete>
                        </button>
                    </div>

                </div>


            </div>
        </div>
    )
}
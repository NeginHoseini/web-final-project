import {Link} from "react-router-dom";
import {useEffect, useState} from "react";
import axios from "axios";
import MovieGrid from "./MovieGrid";
import './MovieGridStyle.css';
import MovieList from "./MovieList";
import Header from "./Header";



export default function GridView() {


    const [movies, setMovies] = useState([]);

    useEffect(() => {
        getMovies();
    }, []);

    function getMovies() {
        axios.get('http://localhost:8888/api/movies/').then(function(response) {
            console.log(response.data);
            setMovies(response.data);
        });
    }


    return (
        <div>
            {/*<h1>List Movies</h1>*/}
            {/*<table cellSpacing={15}>*/}
            {/*    <thead>*/}
            {/*    <tr>*/}
            {/*        <th>#</th>*/}
            {/*        <th>Name</th>*/}
            {/*        <th>Year</th>*/}
            {/*        <th>Description</th>*/}
            {/*        <th>Poster</th>*/}
            {/*    </tr>*/}
            {/*    </thead>*/}
            {/*    <tbody>*/}
            {/*    {movies.map((movie, key) =>*/}
            {/*        <tr key={key}>*/}
            {/*            <td>{movie.id}</td>*/}
            {/*            <td>{movie.name}</td>*/}
            {/*            <td>{movie.year}</td>*/}
            {/*            <td>{movie.description}</td>*/}
            {/*            <td>{movie.poster}</td>*/}
            {/*            <td>*/}
            {/*                /!*<Link to={`user/${user.id}/edit`} style={{marginRight: "10px"}}>Edit</Link>*!/*/}
            {/*                /!*<button onClick={() => deleteUser(user.id)}>Delete</button>*!/*/}
            {/*            </td>*/}
            {/*        </tr>*/}
            {/*    )}*/}

            {/*    </tbody>*/}
            {/*</table>*/}

            <section id={"gridMovies"}
            style={{
                margin:"5% auto",
                width: "95%" ,
                background:"#114431",
                borderRadius: "15px",
                padding: "2%",
            }}
            >
                <h1
                    style={{
                       color:"white",
                       fontFamily:"Andalus",
                    }}
                >Movies</h1>
                <div  className={"moviesCnt"}>

         {/*           <div*/}
         {/*               className="*/}
         {/*py-3 d-flex justify-content-around col-md-3"*/}
         {/*           >*/}


                    {movies.map((movie, key) => (
                        <MovieList id={movie.id}
                              name={movie.name}
                              year={movie.year}
                              description={movie.description}
                              poster={movie.poster}
                              key={key} />
                         ))}
                    </div>
                {/*</div>*/}
            </section>
            <br/>
        </div>
    )
}
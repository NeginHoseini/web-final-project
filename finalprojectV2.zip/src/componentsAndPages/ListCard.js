import {FaEdit} from "react-icons/fa";
import {MdDelete} from "react-icons/md";
import {Link, useNavigate} from "react-router-dom";
import axios from "axios";
import {useEffect, useState} from "react";
import EditModal from "./EditModal";


export default function ListCard({id,name,year,description,poster}) {

    const navigate = useNavigate();
    const [movies, setMovies] = useState([]);

    // useEffect(() => {
    //     getMovies();
    // }, []);
    //
    // function getMovies() {
    //     axios.get('http://localhost:8888/api/movies/').then(function(response) {
    //         console.log(response.data);
    //         setMovies(response.data);
    //     });
    // }


    const deleteMovie = () => {
        // alert("click Delete!");

        axios.delete(`http://localhost:8888/api/movie/delete.php?id=${id}`).then(function(response){
            console.log(response.data);
            window.location.reload();
            // getMovies();
            // navigate('/');
        });
    }


    return (
        <div>
            <div className={"card"}
            style={{
                width:"80%",
                height: "20vh",
                margin:"2% auto",
                background:"#939896",
                fontFamily:"Bahnschrift Condensed",

            }}
            >
                <div className={"row"}>
                    <div className="col-md-2" style={{
                        // border:"red 2px solid"
                    }}>
                        <img
                            style={{height:"18vh"}}
                            className="img-fluid mt-2" src={poster} alt="movie poster" />

                    </div>
                    <div className="col-md-4" style={{
                        fontFamily:"Algerian",
                    }}>
                                    <h3 className={"card-title mt-5 text-start"}> {name} </h3>
                    </div>

                    <div className="col-md-2">
                        <h3 className={"mt-5 text-start"}>({year})</h3>
                    </div>

                    <div className="col-md-2">
                        <Link to={`movie/${id}/detail`} >
                        {/*    <Link to={`${id}/movie/detail`} >*/}
                        <button className={"btn btn-success mt-5"}>Read More...</button>
                        </Link>
                    </div>

                    <div className="col-md-2">
                        <Link to={`movie/${id}/edit`} >
                        <button className={"border-0 mt-5 mx-3"}  style={{
                            height:"30%",
                            background:"#939896"
                        }}
                        >
                            <FaEdit size={30}></FaEdit>
                        </button>
                        </Link>
                        <button onClick={() => deleteMovie()} className={"border-0 mt-5"} style={{
                            height:"30%",
                            background:"#939896"
                        }}
                        >
                        <MdDelete size={30}></MdDelete>
                        </button>
                    </div>

                </div>


            </div>
        </div>
    )
}
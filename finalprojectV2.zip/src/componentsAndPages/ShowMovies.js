import {BsFillGrid3X3GapFill, BsList} from "react-icons/bs";
import {useEffect, useState} from "react";
import axios from "axios";
import ListView from "./ListView";
import GridView from "./GridView";

export default function ShowMovies() {

    const [movies, setMovies] = useState([]);
    const [list,setList] = useState(true);



    function gridView() {
        setList(false);
        localStorage.setItem("view","grid");
    }

    function listView() {
        setList(true);
        localStorage.setItem("view","list");
    }




    useEffect(() => {
        getMovies();
    }, []);

    function getMovies() {
        // axios.get('http://localhost:8888/api/movies/').then(function(response) {
        axios.get(`http://localhost:8888/api/movie/read.php`).then(function(response) {
            console.log(response.data);
            setMovies(response.data);
        });
    }


    return(
        <div>
                <section
                         style={{
                             margin:"5% auto",
                             width: "95%" ,
                             background:"#114431",
                             borderRadius: "15px",
                             padding: "2%",
                         }}
                >
                    <div className={"row"}>

                        <h1 className={"col-md-7 text-end"}
                            style={{
                                color:"white",
                                fontFamily:"Andalus",
                                paddingRight:"3%"
                            }}
                        >Movies</h1>

                        <div className={"col-md-4 text-end pt-1"}>

                            <button className={"border-0 "} style={{
                                background:"#114431",
                                marginRight:"5%",
                            }}
                                onClick={() => listView()}
                            >
                                <BsList style={{color:"white"}} size={30}></BsList>
                            </button>

                            <button className={"border-0 "} style={{
                                background:"#114431"
                            }}
                                onClick={() => gridView()}
                            >
                                <BsFillGrid3X3GapFill className={"mt-1"} style={{color:"white"}} size={22}></BsFillGrid3X3GapFill>
                            </button>
                        </div>

                    </div>


                    {Boolean (localStorage.getItem("view")==="list") ? (
                        <ListView movies={movies} />
                    ) : (
                        <GridView movies={movies} />
                    )}


                    {/*<div  className={"moviesCnt py-3  d-flex justify-content-around "}>*/}
                    {/*<div  className={"w-full grid grid-cols-4 gap-4  justify-between justify-items-stretch space-y-3 space-x-6 rounded-xl  xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 p-11"}>*/}

                    {/*           <div*/}
                    {/*               className="*/}
                    {/*py-3 d-flex justify-content-around col-md-3"*/}
                    {/*           >*/}


                    {/*{movies.map((movie, key) => (*/}
                    {/*    <MovieList id={movie.id}*/}
                    {/*               name={movie.name}*/}
                    {/*               year={movie.year}*/}
                    {/*               description={movie.description}*/}
                    {/*               poster={movie.poster}*/}
                    {/*               key={key} />*/}
                    {/*))}*/}


                    {/*</div>*/}
                    {/*</div>*/}
                </section>
                <br/>
            </div>

    )
}
import {useParams} from "react-router-dom";

export default function Search2(){

    const {SearchedItem} = useParams();
    console.log("Item ->");
    console.log({SearchedItem});

    return(
        <div>
            Search Page
            Item -> {SearchedItem}
        </div>
    )
}
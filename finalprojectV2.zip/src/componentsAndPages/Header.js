import AddMovie from "./AddMovie";
import {useState} from "react";
import axios from "axios";
import {Link} from "react-router-dom";
import ListView from "./ListView";


export default function Header({list}){

    const [searched, setSearched] = useState('');
    const [movies, setMovies] = useState([]);


    const handleSearchSubmit = (event) => {
        event.preventDefault();
        // console.log(searched);
        setSearched('');

        // axios.get(`http://localhost:8888/api/movie/search.php?search=${searched}`).then(function(response) {
        //     setMovies(response.data);
        //     console.log(response.data);
        //
        //     <ListView movies={movies} />
        // });
    }

    const handleChange = (e) => {
        const value = e.target.value;
        setSearched(value);
    }

    // const   = (event) => {
    //     event.preventDefault();
    //     if(isNaN(input.year)){
    //         alert("Movie not added. Enter the information correctly!");
    //         // setInfo("Movie not added. Enter the information correctly!")
    //         // console.log(info);
    //     }else {
    //         axios.post('http://localhost:8888/api/movie/create', input).then(function (response) {
    //             console.log(response.data);
    //
    //             // navigate('/');
    //             setInput({
    //                 name: '',
    //                 year: '',
    //                 description: '',
    //                 poster: '',
    //             });
    //
    //             // setInfo("Movie added successfully!")
    //             // console.log(info);
    //         });
    //
    //     }
    //
    //     }


    return(
        <div>

            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                <div className="container-fluid">
                    <a className="navbar-brand mx-5" href="#">MOVIE</a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
                            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                            {/*<li className="nav-item" style={{color:"white"}}>*/}
                            {/*    <a className="nav-link active" aria-current="page" onClick={"listView"} >List</a>*/}
                            {/*</li>*/}
                            {/*////*/}
                            {/*<li className="nav-item" style={{color:"white"}}>*/}
                            {/*    Grid*/}
                            {/*</li>*/}

                            {/*<li className="nav-item">*/}
                            {/*    <a className="nav-link active" aria-current="page" href="#">Welcome to Movies</a>*/}
                            {/*</li>*/}
                            {/*<li className="nav-item">*/}
                            {/*    <a className="nav-link" href="#">Link</a>*/}
                            {/*</li>*/}

                            {/*<Nav.Link onClick={showGrid}>GRID</Nav.Link>*/}
                            {/*<Nav.Link onClick={showList}>LIST</Nav.Link>*/}
                            {/*<button className={"border-0 "} style={{*/}
                            {/*    width:"50%",*/}
                            {/*    height:"30%",*/}
                            {/*    background:"#252525",*/}
                            {/*    marginRight:"15%",*/}
                            {/*}} onClick={() => listView()} >*/}
                            {/*<BsList style={{color:"white"}} size={30}></BsList>*/}
                            {/*</button>*/}

                            {/*<button className={"border-0 "} style={{*/}
                            {/*    width:"50%",*/}
                            {/*    height:"30%",*/}
                            {/*    background:"#252525"*/}
                            {/*}} onClick={() => gridView()}>*/}
                            {/*<BsFillGrid3X3GapFill className={"mt-1"} style={{color:"white"}} size={22}></BsFillGrid3X3GapFill>*/}
                            {/*</button>*/}
                        </ul>
                        <form className="d-flex" onSubmit={handleSearchSubmit}>
                            <input className="form-control me-2" required placeholder="Search(Name/Year)" value={searched} aria-label="Search"  onChange={handleChange} />
                                {/*<button className="btn btn-outline-success" type="submit">Search</button>*/}

                            <Link to={`movie/search/${searched}`} >
                                <button className="btn btn-outline-success" type="submit">Search</button>
                            </Link>
                        </form>
                    </div>
                </div>
            </nav>

            <AddMovie/>

        </div>
    )

}
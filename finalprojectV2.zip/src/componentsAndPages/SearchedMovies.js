import {BsFillGrid3X3GapFill, BsList} from "react-icons/bs";
import ListView from "./ListView";
import GridView from "./GridView";
import {useEffect, useState} from "react";
import axios from "axios";
import {useParams} from "react-router-dom";
import ListCard from "./ListCard";
import ShowFull from "./ShowFull";

export default function SearchedMovies(){

    const [movies, setMovies] = useState([]);

    const {SearchedVal} = useParams();

    useEffect(() => {
        getMovie();
    }, []);


    function getMovie() {
        // axios.get(`http://localhost:8888/api/movie/search/${searched}`).then(function(response) {
        // axios.get(`http://localhost:8888/api/movie/search.php?search=${searched}`).then(function(response) {
        axios.get(`http://localhost:8888/api/movie/search.php?search=${SearchedVal}`).then(function(response) {
            console.log(response.data);
            setMovies(response.data);
        });
    }


    return(
        <>
        <h1
            style={{
                color:"#114431",
                fontFamily:"Andalus",
                paddingTop:"1%"
            }}
        >Movies</h1>

    <div style={{
            padding: "2%",
            background:"white",
            color: "#d1f6e9",
            fontFamily: "Bahnschrift SemiCondensed",
            // textAlign: "left"
        }}>


            {movies.map((movie, key) => (
                <ShowFull movie={movie}
                          key={key} />
            ))}

            {/*<section*/}
            {/*    style={{*/}
            {/*        margin:"0 auto",*/}
            {/*        width: "90%" ,*/}
            {/*        height:"100vh",*/}
            {/*        background:"#114431",*/}
            {/*        borderRadius: "15px",*/}
            {/*        padding: "2%",*/}
            {/*    }}*/}
            {/*>*/}
            {/*    <div className={"row"}>*/}

            {/*        <h1 className={"col-md-7 text-end"}*/}
            {/*            style={{*/}
            {/*                color:"white",*/}
            {/*                fontFamily:"Andalus",*/}
            {/*                paddingRight:"3%"*/}
            {/*            }}*/}
            {/*        >Movies</h1>*/}

            {/*        <div className={"col-md-4 text-end pt-1"}>*/}

            {/*            /!*<button className={"border-0 "} style={{*!/*/}
            {/*            /!*    background:"#114431",*!/*/}
            {/*            /!*    marginRight:"5%",*!/*/}
            {/*            /!*}}*!/*/}
            {/*            /!*        onClick={() => listView()}*!/*/}
            {/*            /!*>*!/*/}
            {/*            /!*    <BsList style={{color:"white"}} size={30}></BsList>*!/*/}
            {/*            /!*</button>*!/*/}

            {/*            /!*<button className={"border-0 "} style={{*!/*/}
            {/*            /!*    background:"#114431"*!/*/}
            {/*            /!*}}*!/*/}
            {/*            /!*        onClick={() => gridView()}*!/*/}
            {/*            /!*>*!/*/}
            {/*            /!*    <BsFillGrid3X3GapFill className={"mt-1"} style={{color:"white"}} size={22}></BsFillGrid3X3GapFill>*!/*/}
            {/*            /!*</button>*!/*/}
            {/*        </div>*/}

            {/*    </div>*/}

            {/*    <ListView movies={movies} />*/}





            {/*    /!*{Boolean (localStorage.getItem("view")==="list") ? (*!/*/}
            {/*    /!*    <ListView movies={movies} />*!/*/}
            {/*    /!*) : (*!/*/}
            {/*    /!*    <GridView movies={movies} />*!/*/}
            {/*    /!*)};*!/*/}


            {/*    /!*<div  className={"moviesCnt py-3  d-flex justify-content-around "}>*!/*/}
            {/*    /!*<div  className={"w-full grid grid-cols-4 gap-4  justify-between justify-items-stretch space-y-3 space-x-6 rounded-xl  xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 p-11"}>*!/*/}

            {/*    /!*           <div*!/*/}
            {/*    /!*               className="*!/*/}
            {/*    /!*py-3 d-flex justify-content-around col-md-3"*!/*/}
            {/*    /!*           >*!/*/}


            {/*    /!*{movies.map((movie, key) => (*!/*/}
            {/*    /!*    <MovieList id={movie.id}*!/*/}
            {/*    /!*               name={movie.name}*!/*/}
            {/*    /!*               year={movie.year}*!/*/}
            {/*    /!*               description={movie.description}*!/*/}
            {/*    /!*               poster={movie.poster}*!/*/}
            {/*    /!*               key={key} />*!/*/}
            {/*    /!*))}*!/*/}


            {/*    /!*</div>*!/*/}
            {/*    /!*</div>*!/*/}
            {/*</section>*/}
            {/*<br/>*/}
        </div>
        </>
    )
}
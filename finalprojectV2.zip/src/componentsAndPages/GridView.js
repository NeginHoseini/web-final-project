import MovieList from "./ListCard";
import GridCard from "./GridCard";

export default function GridView({movies}){
    return(
        <div>


    {/*        /!*<div  className={"moviesCnt py-3  d-flex justify-content-around "}>*!/*/}
    {/*        /!*<div  className={"w-full grid grid-cols-4 gap-4  justify-between justify-items-stretch space-y-3 space-x-6 rounded-xl  xl:grid-cols-4 lg:grid-cols-3 sm:grid-cols-2 p-11"}>*!/*/}
    {/*            <div className={"row"}>*/}
            {/*           <div*/}
            {/*               className="*/}
            {/*py-3 d-flex justify-content-around col-md-3"*/}
            {/*           >*/}


            {/*{movies.map((movie, key) => (*/}
            {/*    <GridCard id={movie.id}*/}
            {/*               name={movie.name}*/}
            {/*               year={movie.year}*/}
            {/*               description={movie.description}*/}
            {/*               poster={movie.poster}*/}
            {/*               key={key} />*/}
            {/*))}*/}
            {/*</div>*/}
            {/*<div>*/}
    {/*        /!*</div>*!/*/}

            {/*<div className={"row"}>*/}

                <div className={"row"}>
                    {movies.map((movie, key) => (
                        <GridCard id={movie.id}
                                   name={movie.name}
                                   year={movie.year}
                                   description={movie.description}
                                   poster={movie.poster}
                                   key={key} />
                    ))}

                </div>


            </div>


        // </div>
    )
}